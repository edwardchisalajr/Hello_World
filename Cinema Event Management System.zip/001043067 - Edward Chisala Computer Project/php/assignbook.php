<?php

	include('connection.php');
	Session_start();
	
	$_SESSION['Selectedid'];
	$bookid = $_GET['bookid'];
	$_SESSION['bookid'] = $bookid;
	
	
	$check = "SELECT reserveid, staffid  FROM assignedreserve WHERE reserveid ='$_SESSION[bookid]' AND staffid='$_SESSION[Selectedid]'";
	
	$checking = mysqli_query($connect, $check);
	
	$get_all_users = mysqli_fetch_array($checking);
	
	if($get_all_users['reserveid'] == null && $get_all_users['staffid'] == null){
		$query = "INSERT INTO assignedreserve (reserveid, staffid) Values('$_SESSION[bookid]','$_SESSION[Selectedid]')";
		
		$run = mysqli_query($connect, $query);
		
		if($run){
			echo"<script>
			alert('Staff has been assigned to the reservation.');
			window.location='../pages/admin/schedule.php';
			</script>";
		} else {
			echo mysqli_error($connect);
		}
	} else {
		echo"<script>
		alert('Such a staff is already assigned to this resercation.');
		window.location='../pages/admin/staff.php';
		</script>";
	}
?>