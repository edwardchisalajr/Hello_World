<?php
	include ('connection.php');
	Session_start();
	
	$user = mysqli_real_escape_string($connect, $_POST['uname']);
	$pass = mysqli_real_escape_string($connect, $_POST['pass']);
	
	$query = "SELECT * FROM users WHERE userName='$user' AND Password='$pass'";
	
	
	$run = mysqli_query($connect, $query);
	
	$get = mysqli_fetch_array($run);
	
	if($user == $get['userName'] && $pass == $get['password']){
		
		//$_SESSION['username'] = $email;
		$_SESSION['userid'] = $get['userid'];
		$_SESSION['email'] = $get['email'];
		
		if($get['userType'] == 'admin'){
			
			
			
			$_SESSION['userid'] = $get['userid'];
			$_SESSION['email'] = $get['email'];
			echo"<script>
			alert('Welcome to the admin panel $get[userName]');
			window.location='../pages/admin/events.php';
			</script>";
		} else if($get['userType'] == 'customer'){
			$select = "SELECT * FROM customers WHERE email='$get[email]'";
			$run = mysqli_query($connect, $select);
			$fetch = mysqli_fetch_array($run);
			$_SESSION['customerid'] = $fetch['customerid'];
			$_SESSION['userid'] = $get['userid'];
			$_SESSION['email'] = $get['email'];
			echo"<script>
			alert('Welcome to the customer Panel $fetch[fname] $fetch[lname]');
			window.location='../pages/customer/events.php';
			</script>";
		} else if($get['userType'] == 'employee'){
			$select = "SELECT * FROM staffs WHERE email='$get[email]'";
			$run = mysqli_query($connect, $select);
			$fetch = mysqli_fetch_array($run);
			$_SESSION['staffid'] = $fetch['staffid'];
			
			$_SESSION['userid'] = $get['userid'];
			$_SESSION['email'] = $get['email'];
			echo"<script>
			alert('welcome to the Employee Panel $get[userName]');
			window.location='../pages/employee/myevents.php';
			</script>";
		} else {
			echo"<script>
			alert('error...');
			window.location='../index.php';
			</script>";
		}
	} else {
		echo"<script>
		alert('failed to login check your credentials');
		window.location='../index.php';
		</script>";
	}
?>