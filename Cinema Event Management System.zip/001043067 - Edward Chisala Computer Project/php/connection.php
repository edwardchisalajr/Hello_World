<?php
    $host = "localhost";
	$user = "root";
	$password ="";
	$database = "underground";
	$connect = mysqli_connect($host,$user,$password);
	$db_select = mysqli_select_db($connect, $database);
?>