<?php

	include('connection.php');
	Session_start();
	
	$_SESSION['Selectedid'];
	$eventid = $_GET['eventid'];
	$_SESSION['eventid'] = $eventid;
	
	
	$check = "SELECT eventid, staffid  FROM assignedevent WHERE eventid ='$_SESSION[eventid]' AND staffid='$_SESSION[Selectedid]'";
	
	$checking = mysqli_query($connect, $check);
	
	$get_all_users = mysqli_fetch_array($checking);
	
	if($get_all_users['eventid'] == null && $get_all_users['staffid'] == null){
		$query = "INSERT INTO assignedevent (eventid, staffid) Values('$_SESSION[eventid]','$_SESSION[Selectedid]')";
		
		$run = mysqli_query($connect, $query);
		
		if($run){
			echo"<script>
			alert('Staff has been assigned to the event.');
			window.location='../pages/admin/schedule.php';
			</script>";
		} else {
			echo mysqli_error($connect);
		}
	} else {
		echo"<script>
		alert('Such a staff is already assigned to this event.');
		window.location='../pages/admin/staff.php';
		</script>";
	}
?>