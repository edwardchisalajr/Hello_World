<?php
	require 'connection.php';
	
	$selectedid = $_GET['bookid'];
	$_SESSION['Selectedid'] = $selectedid;
	
	$query = "UPDATE reservations SET status = 'approved' WHERE bookid='$_SESSION[Selectedid]'";
	
	$update = mysqli_query($connect, $query);
	
	if($update){
		echo"<script>
		alert('The appointment has been approved');
		window.location='../pages/admin/reserve.php';
		</script>";
	} else {
		mysqli_error($connect);
		echo"<script>
		alert('Failed to approve order please try again');
		window.location='../pages/admin/reserve.php';
		</script>";
	}
?>