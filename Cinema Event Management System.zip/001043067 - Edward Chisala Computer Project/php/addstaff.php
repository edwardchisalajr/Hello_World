<?php

	include('connection.php');
	Session_start();
 
	
	$name = mysqli_real_escape_string($connect, $_POST['name']);
	$lname = mysqli_real_escape_string($connect, $_POST['lname']);
	$sex = mysqli_real_escape_string($connect, $_POST['sex']);
	$age = mysqli_real_escape_string($connect, $_POST['age']);
	$mobile = mysqli_real_escape_string($connect, $_POST['mobile']);
	$mail = mysqli_real_escape_string($connect, $_POST['mail']);
	$uname = mysqli_real_escape_string($connect, $_POST['uname']);
	$pass = mysqli_real_escape_string($connect, $_POST['pass']);
	
	$check = "SELECT fname, lname FROM staffs WHERE fname ='$name' AND lname='$lname'";
	
	$checking = mysqli_query($connect, $check);
	
	$get_all_users = mysqli_fetch_array($checking);
	
	if($get_all_users['fname'] == null && $get_all_users['lname'] == null){
		$query = "INSERT INTO staffs (fname, lname, sex, age, mobile, email) Values('$name','$lname','$sex','$age','$mobile','$mail')";
		$query2 = "INSERT INTO users (userName, password, email, userType) Values('$uname','$pass','$mail','employee')";
		
		$run = mysqli_query($connect, $query);
		$run2 = mysqli_query($connect, $query2);
		
		if($run && $run2){
			echo"<script>
			alert('Staff has been added.');
			window.location='../pages/admin/staff.php';
			</script>";
		} else {
			echo mysqli_error($connect);
		}
	} else {
		echo"<script>
		alert('Such a staff already exists.');
		window.location='../pages/admin/staff.php';
		</script>";
	}
?>