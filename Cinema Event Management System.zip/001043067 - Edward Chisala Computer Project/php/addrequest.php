<?php
session_start();
require('connection.php');
$email = $_SESSION['email'];
$userid = $_SESSION['userid'];
$customerid = $_SESSION['customerid'];


	
	$day = mysqli_real_escape_string($connect, $_POST['day']);
	$duration = mysqli_real_escape_string($connect, $_POST['duration']);
	
	$check = "SELECT * FROM reservations WHERE day ='$day' AND owner='$_SESSION[email]'";
	
	$checking = mysqli_query($connect, $check);
	
	$get_all_users = mysqli_fetch_array($checking);
	
	if($get_all_users['day'] == null && $get_all_users['owner'] == null){
		$query = "INSERT INTO reservations (day, numhrs, status, owner) Values('$day','$duration','not approved','$_SESSION[email]')";
		
		$run = mysqli_query($connect, $query);
		
		if($run){
			echo"<script>
			alert('Appointment has been requested.');
			window.location='../pages/customer/reserve.php';
			</script>";
		} else {
			echo mysqli_error($connect);
		}
	} else {
		echo"<script>
		alert('Failed to request appointment.');
		window.location='../pages/customer/request.php';
		</script>";
	}
	
?>