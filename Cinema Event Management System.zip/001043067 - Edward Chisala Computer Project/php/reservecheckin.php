<?php

	include('connection.php');
	Session_start();
	
	$_SESSION['Selectedid'];
	$_SESSION['staffid'];
	$time = mysqli_real_escape_string($connect, $_POST['time']);
	
	
	$check = "SELECT eventid, staffid  FROM reservecheckin WHERE eventid ='$_SESSION[Selectedid]' AND staffid='$_SESSION[staffid]'";
	
	$checking = mysqli_query($connect, $check);
	
	$get_all_users = mysqli_fetch_array($checking);
	
	if($get_all_users['eventid'] == null && $get_all_users['staffid'] == null){
		$query = "INSERT INTO reservecheckin (eventid, staffid, time) Values('$_SESSION[Selectedid]','$_SESSION[staffid]','$time')";
		
		$run = mysqli_query($connect, $query);
		
		if($run){
			echo"<script>
			alert('Checked in successfully');
			window.location='../pages/employee/myreserves.php';
			</script>";
		} else {
			echo mysqli_error($connect);
		}
	} else {
		echo"<script>
		alert('Already checked in');
		window.location='../pages/employee/myreserves.php';
		</script>";
	}
?>