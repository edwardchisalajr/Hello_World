<?php

	include('connection.php');
	Session_start();
	
	$name = mysqli_real_escape_string($connect, $_POST['name']);
	$type = mysqli_real_escape_string($connect, $_POST['type']);
	$price = mysqli_real_escape_string($connect, $_POST['price']);
	$day = mysqli_real_escape_string($connect, $_POST['day']);
	$time = mysqli_real_escape_string($connect, $_POST['time']);
	
	$check = "SELECT name, day FROM events WHERE name ='$name' AND day='$day'";
	
	$checking = mysqli_query($connect, $check);
	
	$get_all_users = mysqli_fetch_array($checking);
	
	if($get_all_users['name'] == null && $get_all_users['day'] == null){
		$query = "INSERT INTO events (name, type, price, day, time) Values('$name','$type','$price','$day','$time')";
		
		$run = mysqli_query($connect, $query);
		
		if($run){
			echo"<script>
			alert('Event has been added.');
			window.location='../pages/admin/events.php';
			</script>";
		} else {
			echo mysqli_error($connect);
		}
	} else {
		echo"<script>
		alert('Such an event already exists.');
		window.location='../pages/admin/addevent.php';
		</script>";
	}
?>