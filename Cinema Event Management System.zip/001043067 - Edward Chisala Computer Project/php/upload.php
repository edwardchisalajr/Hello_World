<?php
session_start();
require('connection.php');

$user = $_SESSION['email'];
	
	$name = $_POST["filename"];
	$desc = $_POST["desc"];
	$category = $_POST["cat"];
	
	
 
	$file = rand(1000,100000)."-".$_FILES['file']['name'];
	$file_loc = $_FILES['file']['tmp_name'];
	$file_size = $_FILES['file']['size'];
	$file_type = $_FILES['file']['type'];
	$folder="../uploads/";
	 
	// new file size in KB
	$new_size = $file_size/1024;  
	// new file size in KB
	 
	// make file name in lower case
	$new_file_name = strtolower($file);
	// make file name in lower case
	 
	$final_file=str_replace(' ','-',$new_file_name);
	 
	if(move_uploaded_file($file_loc,$folder.$final_file)){
	 
		$query = "INSERT INTO uploads (name, description, category, size, fileType, filePath) VALUES 
		('$name','$desc','$category','$file_size','$file_type','$file')";

		$ret = mysqli_query ($connect, $query);
		if ($ret){
			echo mysqli_error($connect);
			echo"<script>
			alert('File has been added');
			window.location='../pages/admin/movies.php';
			</script>";
		} else {
			echo mysqli_error($connect);
			echo"<script>
			alert('second if statement failed...');
			window.location='../pages/admin/movies.php';
			</script>";
		}
	} else {
		echo"<script>
		alert('First if statement failed...');
		window.location='../pages/member/home.php';
		</script>";
	}
?>