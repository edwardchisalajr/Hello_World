<?php

	include('connection.php');
	Session_start();
	
	$fname = mysqli_real_escape_string($connect, $_POST['fname']);
	$lname = mysqli_real_escape_string($connect, $_POST['lname']);
	$age = mysqli_real_escape_string($connect, $_POST['age']);
	$sex = mysqli_real_escape_string($connect, $_POST['sex']);
	$email = mysqli_real_escape_string($connect, $_POST['email']);
	$mobile = mysqli_real_escape_string($connect, $_POST['mobile']);
	$dis = mysqli_real_escape_string($connect, $_POST['dis']);
	$uname = mysqli_real_escape_string($connect, $_POST['uname']);
	$pass = mysqli_real_escape_string($connect, $_POST['pass']);
	
	$check = "SELECT username, email FROM users WHERE username ='$user' AND email='$email'";
	
	$checking = mysqli_query($connect, $check);
	
	$get_all_users = mysqli_fetch_array($checking);
	
	if($get_all_users['username'] == null && $get_all_users['email'] == null){
		$query = "INSERT INTO users (userName, password, email, userType) Values('$uname','$pass','$email','customer')";
		$query2 = "INSERT INTO customers (fname, lname, age, sex, email, mobile, district) values ('$fname','$lname','$age','$sex','$email','$mobile' ,'$dis')";
		
		$run = mysqli_query($connect, $query);
		$run2 = mysqli_query($connect, $query2);
		
		if($run && $run2){
			echo"<script>
			alert('successful registration');
			window.location='../index.php';
			</script>";
		} else {
			echo mysqli_error($connect);
		}
	} else {
		echo"<script>
		alert('Such a username and email are already in use.');
		window.location='../signup.php';
		</script>";
	}
?>