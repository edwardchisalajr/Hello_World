<?php
require '../phpmailer/PHPMailerAutoload.php';
require 'connection.php';

$mail = mysqli_real_escape_string($connect, $_POST['mail']);
$subject = mysqli_real_escape_string($connect, $_POST['sub']);
$body = mysqli_real_escape_string($connect, $_POST['bod']);

$m = new PHPMailer;
$m->isSMTP();
$m->SMTPAuth = true;

$m->Host = 'smtp.gmail.com';
$m->Username = 'jakobmkanda@gmail.com';
$m->Password = 'jay2000619';
$m->SMTPSecure = 'ssl';
$m->Port = 465;

$m->From = 'chisalaedward@gmail.com';
$m->Fromname = 'Underground Cinema Court';
$m->addReplyTo('', '');
$m->addAddress($mail);

$m->Subject = $subject;
$m->Body = $body;
$m->AltBody = 'This is also an email!';


if($m->send()){
	echo "Email Sent";
	
} else {
	echo $m->ErrorInfo;
}
?>