-- phpMyAdmin SQL Dump
-- version 4.6.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Apr 25, 2019 at 09:30 AM
-- Server version: 5.7.14
-- PHP Version: 5.6.25

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `underground`
--

-- --------------------------------------------------------

--
-- Table structure for table `assignedevent`
--

CREATE TABLE `assignedevent` (
  `assigneid` int(11) NOT NULL,
  `eventid` int(11) NOT NULL,
  `staffid` int(11) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `assignedevent`
--

INSERT INTO `assignedevent` (`assigneid`, `eventid`, `staffid`) VALUES
(1, 1, 2);

-- --------------------------------------------------------

--
-- Table structure for table `assignedreserve`
--

CREATE TABLE `assignedreserve` (
  `assignrid` int(11) NOT NULL,
  `reserveid` int(11) NOT NULL,
  `staffid` int(11) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `assignedreserve`
--

INSERT INTO `assignedreserve` (`assignrid`, `reserveid`, `staffid`) VALUES
(1, 8, 3);

-- --------------------------------------------------------

--
-- Table structure for table `customers`
--

CREATE TABLE `customers` (
  `customerid` int(11) NOT NULL,
  `fname` varchar(30) DEFAULT NULL,
  `lname` varchar(30) DEFAULT NULL,
  `sex` varchar(30) DEFAULT NULL,
  `age` varchar(30) DEFAULT NULL,
  `district` varchar(30) DEFAULT NULL,
  `mobile` varchar(30) DEFAULT NULL,
  `email` varchar(30) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `customers`
--

INSERT INTO `customers` (`customerid`, `fname`, `lname`, `sex`, `age`, `district`, `mobile`, `email`) VALUES
(5, 'Jake', 'Amos', 'Male', '25', 'Blantyre', '+265995810351', 'edo@gmail.com');

-- --------------------------------------------------------

--
-- Table structure for table `eventcheckin`
--

CREATE TABLE `eventcheckin` (
  `checkinid` int(11) NOT NULL,
  `eventid` int(11) NOT NULL,
  `staffid` int(11) NOT NULL,
  `time` time DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `eventcheckout`
--

CREATE TABLE `eventcheckout` (
  `checkoutid` int(11) NOT NULL,
  `eventid` int(11) NOT NULL,
  `staffid` int(11) NOT NULL,
  `time` time DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `events`
--

CREATE TABLE `events` (
  `eventid` int(11) NOT NULL,
  `name` varchar(30) DEFAULT NULL,
  `type` varchar(30) DEFAULT NULL,
  `price` varchar(30) DEFAULT NULL,
  `day` date DEFAULT NULL,
  `time` varchar(30) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `events`
--

INSERT INTO `events` (`eventid`, `name`, `type`, `price`, `day`, `time`) VALUES
(1, 'TITANIC', 'FILM', '7000', '2019-04-18', '12:56'),
(2, 'FASHION SHOW', 'SHOW', '15000', '2019-04-26', '12:56'),
(3, 'SPIDERMAN', 'FILM', '18000', '2019-04-25', '12:56');

-- --------------------------------------------------------

--
-- Table structure for table `forum`
--

CREATE TABLE `forum` (
  `forumid` int(11) NOT NULL,
  `user` varchar(30) DEFAULT NULL,
  `message` text,
  `viewer` varchar(20) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `reservations`
--

CREATE TABLE `reservations` (
  `bookid` int(11) NOT NULL,
  `day` date DEFAULT NULL,
  `numhrs` varchar(30) DEFAULT NULL,
  `status` varchar(30) DEFAULT NULL,
  `owner` varchar(30) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `reservations`
--

INSERT INTO `reservations` (`bookid`, `day`, `numhrs`, `status`, `owner`) VALUES
(8, '2019-05-04', '6', 'approved', 'edo@gmail.com'),
(7, '2019-04-18', '8', 'denied', 'edo@gmail.com');

-- --------------------------------------------------------

--
-- Table structure for table `reservecheckin`
--

CREATE TABLE `reservecheckin` (
  `checkinid` int(11) NOT NULL,
  `eventid` int(11) NOT NULL,
  `staffid` int(11) NOT NULL,
  `time` time DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `reservecheckin`
--

INSERT INTO `reservecheckin` (`checkinid`, `eventid`, `staffid`, `time`) VALUES
(1, 1, 3, '03:01:00');

-- --------------------------------------------------------

--
-- Table structure for table `reservecheckout`
--

CREATE TABLE `reservecheckout` (
  `checkoutid` int(11) NOT NULL,
  `eventid` int(11) NOT NULL,
  `staffid` int(11) NOT NULL,
  `time` time DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `reservecheckout`
--

INSERT INTO `reservecheckout` (`checkoutid`, `eventid`, `staffid`, `time`) VALUES
(1, 1, 3, '03:02:00');

-- --------------------------------------------------------

--
-- Table structure for table `staffs`
--

CREATE TABLE `staffs` (
  `staffid` int(11) NOT NULL,
  `fname` varchar(30) DEFAULT NULL,
  `lname` varchar(30) DEFAULT NULL,
  `sex` varchar(30) DEFAULT NULL,
  `age` varchar(30) DEFAULT NULL,
  `mobile` varchar(30) DEFAULT NULL,
  `email` varchar(30) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `staffs`
--

INSERT INTO `staffs` (`staffid`, `fname`, `lname`, `sex`, `age`, `mobile`, `email`) VALUES
(2, '2323', '232323', 'male', '2323', '232323', '2323@2323'),
(3, 'walt', 'disney', 'male', '54', '232323', 'walt@gmail.com');

-- --------------------------------------------------------

--
-- Table structure for table `tickets`
--

CREATE TABLE `tickets` (
  `ticketid` int(11) NOT NULL,
  `eventid` int(11) NOT NULL,
  `customerid` int(11) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tickets`
--

INSERT INTO `tickets` (`ticketid`, `eventid`, `customerid`) VALUES
(5, 3, 5);

-- --------------------------------------------------------

--
-- Table structure for table `uploads`
--

CREATE TABLE `uploads` (
  `uploadsid` int(11) NOT NULL,
  `name` varchar(50) DEFAULT NULL,
  `description` text,
  `category` varchar(30) DEFAULT NULL,
  `size` int(11) DEFAULT NULL,
  `fileType` varchar(100) DEFAULT NULL,
  `filePath` varchar(100) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `uploads`
--

INSERT INTO `uploads` (`uploadsid`, `name`, `description`, `category`, `size`, `fileType`, `filePath`) VALUES
(6, 'TRAILER', 'FILM TRAILER', 'FILM', 18726037, 'video/mp4', '76057-vid-2.MP4');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `userid` int(11) NOT NULL,
  `userName` varchar(30) DEFAULT NULL,
  `password` varchar(30) DEFAULT NULL,
  `email` varchar(30) DEFAULT NULL,
  `userType` varchar(30) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`userid`, `userName`, `password`, `email`, `userType`) VALUES
(9, '23', '23', '2323@2323', 'employee'),
(2, 'admin', 'admin', 'admin@underground', 'admin'),
(7, 'mala', 'qwe', '', 'employee'),
(8, 'walter', '123123', '', 'employee'),
(6, 'Edo', '123456', 'edo@gmail.com', 'customer'),
(10, 'walter', '123', 'walt@gmail.com', 'employee');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `assignedevent`
--
ALTER TABLE `assignedevent`
  ADD PRIMARY KEY (`assigneid`);

--
-- Indexes for table `assignedreserve`
--
ALTER TABLE `assignedreserve`
  ADD PRIMARY KEY (`assignrid`);

--
-- Indexes for table `customers`
--
ALTER TABLE `customers`
  ADD PRIMARY KEY (`customerid`);

--
-- Indexes for table `eventcheckin`
--
ALTER TABLE `eventcheckin`
  ADD PRIMARY KEY (`checkinid`);

--
-- Indexes for table `eventcheckout`
--
ALTER TABLE `eventcheckout`
  ADD PRIMARY KEY (`checkoutid`);

--
-- Indexes for table `events`
--
ALTER TABLE `events`
  ADD PRIMARY KEY (`eventid`);

--
-- Indexes for table `forum`
--
ALTER TABLE `forum`
  ADD PRIMARY KEY (`forumid`);

--
-- Indexes for table `reservations`
--
ALTER TABLE `reservations`
  ADD PRIMARY KEY (`bookid`);

--
-- Indexes for table `reservecheckin`
--
ALTER TABLE `reservecheckin`
  ADD PRIMARY KEY (`checkinid`);

--
-- Indexes for table `reservecheckout`
--
ALTER TABLE `reservecheckout`
  ADD PRIMARY KEY (`checkoutid`);

--
-- Indexes for table `staffs`
--
ALTER TABLE `staffs`
  ADD PRIMARY KEY (`staffid`);

--
-- Indexes for table `tickets`
--
ALTER TABLE `tickets`
  ADD PRIMARY KEY (`ticketid`);

--
-- Indexes for table `uploads`
--
ALTER TABLE `uploads`
  ADD PRIMARY KEY (`uploadsid`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`userid`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `assignedevent`
--
ALTER TABLE `assignedevent`
  MODIFY `assigneid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `assignedreserve`
--
ALTER TABLE `assignedreserve`
  MODIFY `assignrid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `customers`
--
ALTER TABLE `customers`
  MODIFY `customerid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;
--
-- AUTO_INCREMENT for table `eventcheckin`
--
ALTER TABLE `eventcheckin`
  MODIFY `checkinid` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `eventcheckout`
--
ALTER TABLE `eventcheckout`
  MODIFY `checkoutid` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `events`
--
ALTER TABLE `events`
  MODIFY `eventid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
--
-- AUTO_INCREMENT for table `forum`
--
ALTER TABLE `forum`
  MODIFY `forumid` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `reservations`
--
ALTER TABLE `reservations`
  MODIFY `bookid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;
--
-- AUTO_INCREMENT for table `reservecheckin`
--
ALTER TABLE `reservecheckin`
  MODIFY `checkinid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `reservecheckout`
--
ALTER TABLE `reservecheckout`
  MODIFY `checkoutid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `staffs`
--
ALTER TABLE `staffs`
  MODIFY `staffid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT for table `tickets`
--
ALTER TABLE `tickets`
  MODIFY `ticketid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;
--
-- AUTO_INCREMENT for table `uploads`
--
ALTER TABLE `uploads`
  MODIFY `uploadsid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;
--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `userid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
