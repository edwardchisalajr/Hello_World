<?php
	include'../../php/connection.php';
	
	Session_start();
	
	$selectedid = $_GET['eventid'];
	$_SESSION['Selectedid'] = $selectedid;
	
	$query = "DELETE from events WHERE eventid ='$_SESSION[Selectedid]'";
	
	
	$delete = mysqli_query($connect, $query);
	
	
	if($delete){
		echo"<script>
		alert('The event has successfully been deleted');
		window.location='events.php';
		</script>";
	} else {
		echo"<script>
		alert('Failed to delete event please try again');
		window.location='events.php';
		</script>";
	}
?>