<?php
	include'../../php/connection.php';
	
	Session_start();
	
	$selectedid = $_GET['staffid'];
	$_SESSION['Selectedid'] = $selectedid;
	
	$query = "DELETE from users WHERE email ='$_SESSION[Selectedid]'";
	$query1 = "DELETE from staffs WHERE email ='$_SESSION[Selectedid]'";
	
	
	$delete = mysqli_query($connect, $query);
	$delete1 = mysqli_query($connect, $query1);
	
	
	if($delete && $delete1){
		echo"<script>
		alert('The staff has successfully been deleted');
		window.location='staff.php';
		</script>";
	} else {
		echo"<script>
		alert('Failed to delete staff please try again');
		window.location='staff.php';
		</script>";
	}
?>