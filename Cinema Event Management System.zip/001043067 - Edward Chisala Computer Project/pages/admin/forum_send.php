<?php
require_once('../../php/connection.php');
session_start();

	$SessionUserName = $_SESSION["Username"];
	$SessionUserID = $_SESSION["email"];
	
	if (isset($_POST["message"])){
		$Message = $_POST["message"];
		$query = "insert into forum(user,Message) values('$SessionUserID','$Message')";
		$ret = mysqli_query ($connect, $query);
		header('Location:forum.php');

		if($Message==""){
			$Message=null;
		}
	}
?>