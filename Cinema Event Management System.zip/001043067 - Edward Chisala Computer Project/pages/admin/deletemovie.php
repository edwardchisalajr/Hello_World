<?php
	include'../../php/connection.php';
	
	Session_start();
	
	$selectedid = $_GET['uploadsid'];
	$_SESSION['Selectedid'] = $selectedid;
	
	$query = "DELETE from uploads WHERE uploadsid ='$_SESSION[Selectedid]'";
	
	
	$delete = mysqli_query($connect, $query);
	
	
	if($delete){
		echo"<script>
		alert('The movie has successfully been deleted');
		window.location='movies.php';
		</script>";
	} else {
		echo"<script>
		alert('Failed to delete movie please try again');
		window.location='movies.php';
		</script>";
	}
?>