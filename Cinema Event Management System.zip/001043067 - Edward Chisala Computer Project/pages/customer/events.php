<?php
session_start();
require('../../php/connection.php');
$email = $_SESSION['email'];
$userid = $_SESSION['userid'];
$customerid = $_SESSION['customerid'];
$select = "SELECT * FROM customers WHERE customerid='$_SESSION[customerid]'";
$run = mysqli_query($connect, $select);
$fetch = mysqli_fetch_array($run);
?>
<!DOCTYPE html>
<!--[if lt IE 7]>      <html class="no-js lt-ie9 lt-ie8 lt-ie7" lang=""> <![endif]-->
<!--[if IE 7]>         <html class="no-js lt-ie9 lt-ie8" lang=""> <![endif]-->
<!--[if IE 8]>         <html class="no-js lt-ie9" lang=""> <![endif]-->
<!--[if gt IE 8]><!-->
<html class="no-js" lang="en">
<!--<![endif]-->

<html>
	<head>
	<meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta charset="utf-8"/>
		<title>Welcome | <?php  echo $fetch['fname'] . " " . $fetch['lname']?></title>
		<!--[if lt IE 7]>      <html class="no-js lt-ie9 lt-ie8 lt-ie7" lang=""> <![endif]-->
<!--[if IE 7]>         <html class="no-js lt-ie9 lt-ie8" lang=""> <![endif]-->
<!--[if IE 8]>         <html class="no-js lt-ie9" lang=""> <![endif]-->
<!--[if gt IE 8]><!-->
<html class="no-js" lang="en">
    <meta name="description" content="Sufee Admin - HTML5 Admin Template">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <link rel="apple-touch-icon" href="apple-icon.png">
    <link rel="shortcut icon" href="favicon.ico">


    <link rel="stylesheet" href="../../vendors/bootstrap/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="../../vendors/font-awesome/css/font-awesome.min.css">
    <link rel="stylesheet" href="../../vendors/themify-icons/css/themify-icons.css">
    <link rel="stylesheet" href="../../vendors/flag-icon-css/css/flag-icon.min.css">
    <link rel="stylesheet" href="../../vendors/selectFX/css/cs-skin-elastic.css">

    <link rel="stylesheet" href="../../assets/css/style.css">

    <link href='https://fonts.googleapis.com/css?family=Open+Sans:400,600,700,800' rel='stylesheet' type='text/css'>



</head>

<body>
    <!-- Left Panel -->

    <aside id="left-panel" class="left-panel">
        <nav class="navbar navbar-expand-sm navbar-default">

            <div class="navbar-header">
                <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#main-menu" aria-controls="main-menu" aria-expanded="false" aria-label="Toggle navigation">
                    <i class="fa fa-bars"></i>
                </button>
                <a class="navbar-brand" href="events.php">The Underground</a>
            </div>

            <div id="main-menu" class="main-menu collapse navbar-collapse">
                <ul class="nav navbar-nav">
                    <li>
                        <a href="events.php"> Events </a>
                    </li>
					<li>
                        <a href="movies.php">Trailers </a>
                    </li>
					<li>
                        <a href="tickets.php">My Tickets </a>
                    </li>
					<li>
                        <a href="reserve.php">My Stage Reservations </a>
                    </li>
					<li>
                        <a href="forum.php">Forum Form </a>
                    </li>
					<li>
                        <a href="../../php/logout.php"> Sign out </a>
                    </li>
                    
                </ul>
            </div><!-- /.navbar-collapse -->
        </nav>
    </aside><!-- /#left-panel -->

    <!-- Left Panel -->

    <!-- Right Panel -->

    <div id="right-panel" class="right-panel">

        <!-- Header-->
        <header id="header" class="header">

            <div class="header-menu">

                <div class="col-sm-7">
                    <a id="menuToggle" class="menutoggle pull-left"><i class="fa fa fa-tasks"></i></a>
                    <div class="header-left">
                        
                    </div>
                </div>

                <div class="col-sm-5">
                    

                </div>
            </div>

        </header><!-- /header -->
        <!-- Header-->

								<table class="table table-striped" width="80%">
								    <tr>
										<th>NAME</th><th>TYPE</th><th>PRICE (MWK)</th><th>DAY</th><th>TIME</th><th>RESERVE TICKET</th>
								    </tr>
								<?php
									require_once('../../php/connection.php');
									$sql="SELECT * FROM events";
									$result_set=mysqli_query($connect, $sql);
									while($row=mysqli_fetch_array($result_set)){
								?>
					        	<tr>
					        		<td><?php echo $row['name']?></td>
					        		<td><?php echo $row['type'] ?></td>
									<td><?php echo $row['price'] ?></td>
									<td><?php echo $row['day'] ?></td>
									<td><?php echo $row['time'] ?></td>
									
									<td><a href="purchase.php?eventid=<?php echo $row['eventid'] ?>">Reserve</a></td>
					       		 </tr>	
								<?php
									}		
								?>
								</table>
							</div>
						</div>
						
					</div>
				</div>
			</div>
			
	  
		</header>
		<script src="../../vendors/jquery/dist/jquery.min.js"></script>
    <script src="../../vendors/popper.js/dist/umd/popper.min.js"></script>
    <script src="../../vendors/bootstrap/dist/js/bootstrap.min.js"></script>
    <script src="../../assets/js/main.js"></script>
	</body>
</html>