<?php
session_start();
require('../../php/connection.php');
$email = $_SESSION['email'];
$userid = $_SESSION['userid'];
$customerid = $_SESSION['customerid'];
$selectedid = $_GET['eventid'];
$_SESSION['Selectedid'] = $selectedid;
	
	
	$check = "SELECT * FROM tickets WHERE ticketid =NULL";
	
	$checking = mysqli_query($connect, $check);
	
	$get_all_users = mysqli_fetch_array($checking);
	
	if($get_all_users['ticketid'] == null){
		$query = "INSERT INTO tickets (eventid, customerid) Values('$_SESSION[Selectedid]','$_SESSION[customerid]')";
		
		$run = mysqli_query($connect, $query);
		
		if($run){
			echo"<script>
			alert('Ticket has been purchased.');
			window.location='tickets.php';
			</script>";
		} else {
			echo mysqli_error($connect);
		}
	} else {
		echo"<script>
		alert('Failed to purchase ticket please try again.');
		window.location='events.php';
		</script>";
	}
	
?>